import json
from pprint import pprint
def check_rp(ipaddr):
    
    with open('inferences_remote.txt') as ref:
        for line in ref:
            parts=line.split('\t')
            if ipaddr==parts[1]:
                return line
    return 0


text=''
with open('nl-ams_2018012719_unicast_addr.json') as g:
    data=json.load(g)

for i in data:
    for j in i['result']:
        if len(j['result'][0])>=4:
            ip=j['result'][0]['from']
            #print(ip)
            res=check_rp(ip)
            if res!=0:
                print(i)
                print(res)
                



























